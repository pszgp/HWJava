d3 = {version: "2.8.1"}; // semver
